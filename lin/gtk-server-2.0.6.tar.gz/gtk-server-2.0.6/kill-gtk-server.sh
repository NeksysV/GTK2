#!/bin/bash
#
# Check usage
if [ "$#" -eq 0 ]
then
	echo
	echo "*** Kill GTK-server processes ***"
	echo
	echo "Usage: kill-gtk-server.sh <stdin>|<tcp>|<udp>|<fifo>"
	echo
	exit 1

# Check if we are going to kill FIFO gtk-server processes
elif [ $1 == "fifo" ]
then
	# Determine PIPE file first
	FILES=`ps -ef | grep -v ps | awk '/gtk-server fifo/ {print $10}'`

	# Kill gtk-server fifo processes
	for i in `ps -ef | grep -v ps | awk '/gtk-server fifo/ {print $2}'`
	do
		kill -9 $i
		echo "Process $i killed."
	done

	# Then remove pipe files from /tmp directory
	for i in $FILES
	do
		if [ -p $i ]
		then
			rm $i
			echo "Pipefile ${i} removed."
		fi
	done

# Check on TCP process
elif [ $1 == "tcp" ]
then
	# Kill gtk-server tcp processes
	for i in `ps -ef | grep -v ps | awk '/gtk-server tcp/ {print $2}'`
	do
		kill -9 $i
		echo "Process $i killed."
	done

# Check on UDP process
elif [ $1 == "udp" ]
then
	# Kill gtk-server udp processes
	for i in `ps -ef | grep -v ps | awk '/gtk-server udp/ {print $2}'`
	do
		kill -9 $i
		echo "Process $i killed."
	done

# Check if we are going to kill STDIN gtk-server processes
elif [ $1 == "stdin" ]
then
	# Kill gtk-server fifo processes
	for i in `ps -ef | grep -v ps | awk '/gtk-server stdin/ {print $2}'`
	do
		kill -9 $i
		echo "Process $i killed."
	done
# Generate error warning -> argument not recognized
else
	echo "Argument not recognized!"
	echo "Run kill-gtk-server.sh to see usage."
fi

exit 0
