#!/bin/sh
#
# Create Slackware package
# Peter van Eerten, peter@gtk-server.org
#
#---------------------------------------

VERSION=$1
PKG_NAME=gtk-server-$1-i386-1pve
if [ -z $1 ]
then
	echo "---> Provide version number <---"
	exit
fi

#---------------------------------------

USER=`whoami`
if [ $USER != "root" ]
then
	echo "Only root can create a package."
	exit
fi

#---------------------------------------

if [ -d slackpack ]
then
	echo "Warning: temporary directory 'slackpack' exists!"
	exit
fi

#---------------------------------------

echo "Creating Slack package..."
# Configfile
mkdir -p slackpack/etc
cp gtk-server.cfg slackpack/etc/
chmod 644 slackpack/etc/gtk-server.cfg
# Manpages
mkdir -p slackpack/usr/man/man1
cp gtk-server.1 slackpack/usr/man/man1/
chmod 644 slackpack/usr/man/man1/gtk-server.1
cp gtk-server.cfg.1 slackpack/usr/man/man1/
chmod 644 slackpack/usr/man/man1/gtk-server.cfg.1
gzip slackpack/usr/man/man1/gtk-server.1
gzip slackpack/usr/man/man1/gtk-server.cfg.1
# Documentation + license
mkdir -p slackpack/usr/doc/gtk-server
cp docs/* slackpack/usr/doc/gtk-server/
chmod 444 slackpack/usr/doc/gtk-server/*.html
cp demo/* slackpack/usr/doc/gtk-server/
chmod 755 slackpack/usr/doc/gtk-server/demo*
cp README slackpack/usr/doc/gtk-server/
chmod 444 slackpack/usr/doc/gtk-server/README
cp CREDITS slackpack/usr/doc/gtk-server/
chmod 444 slackpack/usr/doc/gtk-server/CREDITS
cp GPL.txt slackpack/usr/doc/gtk-server/
chmod 444 slackpack/usr/doc/gtk-server/GPL.txt
# Binary
mkdir slackpack/usr/bin
chown root:bin slackpack/usr/bin/
cp gtk-server slackpack/usr/bin/
chmod 755 slackpack/usr/bin/gtk-server
chown root:bin slackpack/usr/bin/gtk-server
cp kill-gtk-server.sh slackpack/usr/bin/
chmod 755 slackpack/usr/bin/kill-gtk-server.sh
chown root:bin slackpack/usr/bin/kill-gtk-server.sh
# Library
mkdir slackpack/usr/lib
cp gtk-server.so slackpack/usr/lib/
chmod 755 slackpack/usr/lib/gtk-server.so
cp gtk-module.so slackpack/usr/lib/
chmod 755 slackpack/usr/lib/gtk-module.so
# Add description
mkdir -p slackpack/install
echo "gtk-server: gtk-server $VERSION - Interpreted GUI Programming" >> slackpack/install/slack-desc
echo "gtk-server:" >> slackpack/install/slack-desc
echo "gtk-server: The GTK-server enables GUI access to script- and" >> slackpack/install/slack-desc
echo "gtk-server: interpreted languages, using the famous GTK widget" >> slackpack/install/slack-desc
echo "gtk-server: set. It can be used with Bourne Shell, Korn Shell," >> slackpack/install/slack-desc
echo "gtk-server: GNU Awk, CLisp, newLisp, Perl, CShell and many other" >> slackpack/install/slack-desc
echo "gtk-server: languages." >> slackpack/install/slack-desc
echo "gtk-server:" >> slackpack/install/slack-desc
echo "gtk-server: More info at http://www.gtk-server.org/" >> slackpack/install/slack-desc
echo "gtk-server:" >> slackpack/install/slack-desc
echo "gtk-server: Package Created By: Peter van Eerten" >> slackpack/install/slack-desc

# Create package
cd slackpack
makepkg -c n $PKG_NAME.tgz

# Save package, remove temp dir
cd ..
mv slackpack/$PKG_NAME.tgz .
rm -rf slackpack/

# Exit
echo "Ready."
