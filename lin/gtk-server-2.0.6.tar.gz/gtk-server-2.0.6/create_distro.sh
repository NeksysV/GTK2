#!/usr/bin/bash
#
# Cleanup mess and generate source distribution file
# Peter van Eerten, peter@gtk-server.org
#
VERSION=$1
DIR=gtk-server-$1
if [ -z $1 ]
then
	echo "---> Provide version number: x.y.z <---"
	exit
fi
make clean >/dev/null 2>&1
rm -f config.h
rm -f config.log
rm -f config.status
rm -f configure
rm -f Makefile
rm -f *.tar.gz
if [ ! -f $DIR.spec ]
then
	mv *.spec $DIR.spec
fi
autoconf
rm -rf autom4te.cache
touch *
mkdir $DIR
cp * $DIR/ > /dev/null 2>&1
mkdir $DIR/demo/
cp ../site/demo-tcp.bash.txt $DIR/demo/demo-tcp.bash
cp ../site/demo-fifo.bash.txt $DIR/demo/demo-fifo.bash
cp ../site/demo-stdin.ksh.txt $DIR/demo/demo-stdin.ksh
cp ../site/demo-fifo.ksh.txt $DIR/demo/demo-fifo.ksh
cp ../site/demo-stdin.awk.txt $DIR/demo/demo-stdin.awk
cp ../site/demo-fifo.awk.txt $DIR/demo/demo-fifo.awk
cp ../site/demo-tcp.awk.txt $DIR/demo/demo-tcp.awk
cp ../site/demo-udp.awk.txt $DIR/demo/demo-udp.awk
cp ../site/demo-tcp.lsp.txt $DIR/demo/demo-tcp.lsp
cp ../site/demo-udp.lsp.txt $DIR/demo/demo-udp.lsp
cp ../site/demo-fifo.lsp.txt $DIR/demo/demo-fifo.lsp
cp ../site/demo-stdin.lsp.txt $DIR/demo/demo-stdin.lsp
cp ../site/demo-fifo.perl.txt $DIR/demo/demo-fifo.pl
cp ../site/demo-stdin.perl.txt $DIR/demo/demo-stdin.pl
cp ../site/demo-stdin.clisp.txt $DIR/demo/demo-stdin.clisp
cp ../site/demo-tcp.clisp.txt $DIR/demo/demo-tcp.clisp
cp ../site/demo-lib.sl.txt $DIR/demo/demo-lib.sl
cp ../site/demo-lib.lsp.txt $DIR/demo/demo-lib.lsp
mkdir $DIR/docs/
cp ../site/GTK-server_Manual.html $DIR/docs/
cp ../site/GTK-server_Tutorial.html $DIR/docs/
cp ../site/gtk-server.1.html $DIR/docs/
cp ../site/gtk-server.cfg.1.html $DIR/docs/
tar -cf $DIR.tar $DIR/
rm -rf $DIR
gzip $DIR.tar
echo "Distribution ready."
