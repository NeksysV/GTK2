#!/bin/sh
#
# Bourne shell named pipe demo with the gtk-server
#
# March 14, 2004 by Peter van Eerten
# Revised at july 25, 2004
# Revised for GTK-server 1.2 October 7, 2004
# Revised for GTK-server 1.3 December 4, 2004
#------------------------------------------------

# Communicate with GTK-server
gtk()
{
echo $1 > /tmp/shdemo
RESULT=`cat /tmp/shdemo`
}

#------------------------ Main starts here

# Start gtk-server
gtk-server fifo /tmp/shdemo &

# Wait for the server to initialize
sleep 1

# Setup GUI
gtk "gtk_init NULL NULL"
gtk "gtk_window_new 0"
WIN=$RESULT
gtk "gtk_window_set_title $WIN \"Bourne GTK-SERVER demo\""
gtk "gtk_window_set_default_size $WIN 400 200"
gtk "gtk_window_set_position $WIN 1"
gtk "gtk_table_new 10 10 1"
TBL=$RESULT
gtk "gtk_container_add $WIN $TBL"
gtk "gtk_button_new_with_label \"Click to Quit\""
BUT=$RESULT
gtk "gtk_table_attach_defaults $TBL $BUT 5 9 5 9"
gtk "gtk_widget_show_all $WIN"

EVENT=0

# Mainloop
while [ $EVENT -ne $BUT ]
do 
	gtk "gtk_server_callback WAIT"
	EVENT=$RESULT
done

# Exit GTK without waiting for an answer
echo "gtk_exit 0" > /tmp/shdemo
