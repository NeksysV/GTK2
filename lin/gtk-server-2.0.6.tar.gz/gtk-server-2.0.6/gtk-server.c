/**************************************************************************
*
* This is the infamous GTK-SERVER. The purpose of this program is to enable
* access to graphical GTK widgets for shell scripts and interpreted
* languages. Currently these languages have been tested successfully:
*
* -KSH (stdin)
* -ZSH (stdin)
* -AWK (stdin, tcp)
* -BASH (tcp, fifo)
* -Cshell (fifo)
* -Rebol (tcp)
* -TCL (tcp)
* -Scriptbasic (tcp, fifo)
* -Prolog (tcp)
* -Python (tcp)
* -newLISP (tcp)
* -CLISP (tcp)
* -PHP (tcp, stdin)
* -VB Script (stdin, fifo)
* -Yabasic (fifo)
* -Perl (fifo)
* -Ash (fifo)
* -Ruby (tcp)
* -Icon (fifo)
* -Logo (fifo)
* -Bas (fifo)
* -Expect (stdin)
* -Lua (fifo)
* -S-lang (fifo)
* -Scheme (stdin)
* -Rexx (fifo)
*
* Please read the documentation on how to use this program.
* The CREDITS file lists all people who have helped improving the GTK-server.
*
* Original idea and design by Peter van Eerten, september 2003 - september 2005
* Mail: peter@gtk-server.org
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*
* You should have received a copy of the GNU General Public License
* along with this program; if not, write to the Free Software
* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
*
* See http://www.gnu.org/licenses/gpl.txt for the full version of this license.
*
* TODO
* - Better errorhandling
*
* CHANGES GTK-SERVER 1.0
* ----------------------
* - BUILD 1:	. Intitial release
* - BUILD 2:	. Fixed bug in parsing GTK-function arguments with Trim_Spaces
* - BUILD 3:	. Removed the child process counter, the Linux TCP version will run standalone now,
*				  and an explicit kill is required.
* - BUILD 4:	. Show help even when configfile is not available
*				. Lines in configfile 'gtk-server.cfg' may be empty now
*				. Name of the external gtk-library is configurable now
* - BUILD 5:	. Changed the format of the gtk-server.cfg file
*				. Added callback signal "RELEASE"
* - BUILD 6:	. Added ability to return a LONG from a GTK-function
*   			. Code cleaning
* - BUILD 7:	. Enable logging facility
* - BUILD 8:	. A lot of code optimizations - source has become smaller
* - BUILD 9:	. Implemented workaround for floating point arguments
*				. Changed logfile name to 'gtk-server.log'
*
* CHANGES GTK-SERVER 1.1
* ----------------------
* - BUILD 1:	. Redesigned the callback mechanism, hence the new release number (1.1)
*				. Updated the Check_Exceptions routine with GTK2.x functions
*				. Changed Widget casting from GtkWidget to GtkObject
*				. Added ability to return a FLOAT from a GTK-function
* - BUILD 2:	. Improved logging facility; returned string will be logged as well
* - BUILD 3:	. Determine maximum clients as an argument to the gtk-server (Linux)
* - BUILD 4:	. Look for global gtk-server.cfg as well (Linux: /etc directory)
* - BUILD 5:	. Path for logfile is configurable now in the gtk-server.cfg file
* - BUILD 6:	. Removed the GTK_LIB_SIGNAL keyword, signals can be configured directly now.
*				. Also search the /usr/local/etc directory for a configfile
* - BUILD 7:	. Added code to compile a self-containing GTK-server with all the
*				  GTK libs included
* - BUILD 8:	. Fixed some illegal memory writes and leaks pointed out by Valgrind
*				. Changed Win32 functionality: server will kill itself if a client
*   			  script disconnects
* - BUILD 9:	. Named pipe support (Unix/Linux)
*				. Some small code optimizations
* - BUILD 10:	. Support for named pipes in Win32
* - BUILD 11:	. Support for STDIN in Win32 (CLisp, Prolog, VB Script)
* - BUILD 12:	. Workaround for passing strings containing comma's as argument - introducing
*   			  the GTK_SERVER_COMMA config option
*   			. Added some GTK2 float functions
*   			. Win32 logic for finding the configfile
* - BUILD 13:	. Improved Named Pipe support for Windows
*   			. Fixed potential bug with creating the logfile
* - BUILD 14:	. Introducing environment variable GTK_SERVER_CONFIG to point to
*   			  configfile (WIN + LINUX)
*				. The Win32 version is not console based anymore. Adjusted all error warnings
*				  to messageboxes.
* - BUILD 15:	. Solved crash when GTK_SERVER_COMMA option is not present
*   			. Installer for Win32
*   			. Autoconf source for Linux
* - BUILD 16:	. Implemented UDP communication interface: gtk-server udp <host:ip> [log]
*				. Argument syntax for TCP has changed: gtk-server tcp <host:ip[:max]> [log]
*				. Improved Makefile for Windows
* - BUILD 17:	. Added float functions for GTK2
*				. Corrected the Linux help prompt
*				. Removed redundant code
* - BUILD 18:	. Centralized version indication of GTK-server
*				. Added internal 'gtk_server_version' command to retrieve version
*				. If a LONG argument contains letters it will switch to STRING automatically
*				. Some large code improvements
*				. Win32: always create a logfile to capture GTK errors
*				. Bugfix: the GTK-server will not crash anymore when sending empty arguments
*				. Bugfix: float values are parsed correctly now in Win32 environments (Linux was already working)
* - BUILD 19:	. Linux: FIFO communication will return result string with newline attached
*				. Linux: improved FIFO to synchronous writing (added O_SYNC flag)
*				. Linux: Added experimental FILE interface (SLOW!)
*				. Win/Linux: Fixed bug with ')' symbol - introducing GTK_SERVER_BRACKET config option
*				. Linux distribution provides convenient KILL script to kill hanging gtk-servers
*
* CHANGES GTK-SERVER 1.2
* ----------------------
* - BUILD 1:	. Major changes in callback functionality by ideas of mr. Joe Armstrong; hence new releasenumber
*				. Ability to add extra signals per widget, each with own identifier
*				. Bugfix: returning empty STRING from GTK widget does not crash GTK-server anymore
*   			. Bugfix: do not crash with '-1' as widget reference
*				. Improvements in the GTK-server KILL-script (Linux)
* - BUILD 2:	. The callback function only returns registered events now if called with 'WAIT'
*   			. The callback function now knows asynchronous "update" as argument
*   			. Generate error message when arguments to GTK-server are not recognized
*   			. Bugfix: reading CONFIG environment variable (Linux)
*				. More improvements in the GTK-server KILL-script (Linux)
*				. HOTFIX: STDIN interface can read newlines now
* - BUILD 3:	. Improved configure script to force compilation with GTK2
*				. Corrected 'gtk-server.cfg' search order for Linux
*				. Corrected format of logging with TCP and UDP
*				. The GTK-server now compiles with -pedantic flag and is ISO-C compatible (Linux)
*				. Added scripts to create sourcepackage, Slackware installpackage and SRC rpm
*   
* CHANGES GTK-SERVER 1.3
* ----------------------
* - BUILD 1:	. Major changes in passing strings to GTK-server; concept by Norman Deppendbroek, parser
*				  created by Jim Bailey, slightly modified for GTK-server (me)
*				. The configoptions 'GTK_SERVER_COMMA' and 'GTK_SERVER_BRACKET' are redundant now
*				. Improved Trim_String function by Jim Bailey
*				. Linux: search for configfile '.gtk-server.cfg' in homedirectory of user also
* - BUILD 2:	. Fixed severe memory leak in callback routines
*				. GTK-server should compile without problems on FreeBSD now
* - BUILD 3:	. Finalized complete solution for FLOAT arguments
*				. Support for opening extra library with GTK_LIB_EXTRA
*				. Removed the experimental FILE interface
* - BUILD 4:	. Fixed compile warning with GTK1.x
*				. Fixed environment variable mixup (Felix Winkelmann, Sebastiaan van Erk)
*				. Fixed STDIN loop exit problems (Sebastiaan van Erk)
*				. Changes in MAN pages
*				. Changes in static Makefile
*				. Removed FILE interface from GTK-server KILL script
*				. Updated gtk-server.cfg file to latest
*
* CHANGES GTK-SERVER 2.0
* ----------------------
* - BUILD 1:	. Major changes in passing arguments and realizing GTK functions. Using FFI now, which
*				  also solves the FLOAT problem structurally
*				. Ability to capture incoming values in callback function
*				. Improved the Print_Error routine
*				. All error warnings go to the same function now
* - BUILD 2:	. Fixed erronuous Errormessages with DLOPEN
*				. Added floattype to FFI structure for compatibility with GTK 1.x
*				. Fixed compilewarnings for sprintf and vsprintf on OpenBSD
*				. Fixed issue with 'strtof' on OpenBSD
*				. Fixed unresolved PTHREAD symbol on OpenBSD
*				. Applied patches to obey --prefix flag (Peter Bui)
* - BUILD 3:	. Fixed bug with listening to extra signals (Woflgang Oertl)
*				. Up to 8 callback arguments can be retrieved now
*				. Implemented BOOL type, interchangable with LONG
*				. Returnbuffer is now of flexible size
*				. Option GTK_SERVER_ENABLE_C_STRING_ESCAPING to set escaping in returned strings (Jeremy Shute)
*				. Code cleanups
* - BUILD 4:	. Fixed minor bug with returning widgetID in "gtk_server_callback_value"
*				. Added support for mouse events with "gtk_server_mouse"
*				. Updated and corrected the manpages
* - BUILD 5:	. Added errormessage when returnvalue of GTK call in configfile is not correct
*				. Added GDK_LIB_NAME and GLIB_LIB_NAME in configfile
*				. Improved the Win32 Makefile
*				. Added "gtk_server_redefine" to change API calls on the fly
*				. Fixed OpenBSD compilewarning with sprintf
* - BUILD 6:	. Changed the signal connect functions to 'signal_connect_after'
*				. Fixed configure script to compile on Solaris
*				. Now the GTK-server in FIFO mode removes pipe file by itself at normal exit (Linux, BSD)
*				. Removed the O_SYNC from the FIFO interface, Linux does not need it and MacOSX cannot compile with it
*				. Code optimizations in the Call_Realize function
*				. Added LIBRARY interface -> GTK-server can be compiled as SO/DLL now
*				. GTK-server also can be compiled as S-Lang module
*
* Improvements by others:
* -----------------------
* - 24/01/2004:	Fixed compile problem with GCC 2.96 Redhat 7.1 (thanks Larry Richardson), fix
*   			included since 1.1 build 7.
*   
***************************************************************************/

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef SLANG
#include <slang.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <gtk/gtk.h>
#include <locale.h>
#include <unistd.h>
#include <sys/stat.h>
#include <ffi.h>

#ifdef LINUX
#include <netdb.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <arpa/inet.h>
#include <signal.h>
#include <dlfcn.h>
#include <stdarg.h>
/* Needed for FIFO files */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#endif

#ifdef BSD
#include <netinet/in.h>
#endif

#ifdef WIN32
#include <strings.h>
#include <winsock.h>
#include <windows.h>
#include <shlwapi.h>
#endif

#ifndef LOCALCFG
#define LOCALCFG "/usr/local/etc/gtk-server.cfg"
#endif

/* Define global constants */
#define MAX_LEN 1024		/* max length of a STDIN coming from script or configfile */

/* Define how many arguments may be used for a GTK function */
#define MAX_ARGS 32

/* Define callback signals */
#define GTK_SERVER_NONE 0

/* Define GTK-server version */
#define VERSION "2.0 build 6"

/* Define backlog for tcp-connections */
#define BACKLOG 4

/* Define some inputs and outputs */
enum { STDIN, STDOUT, STERR };

/* Define structure containing configuration data */
typedef struct config_struct {
	int counter;
	char *name;
	char *callbacktype;
	char *returnvalue;
	char *argamount;
	char *args[MAX_ARGS];
	struct config_struct *next;
} CONFIG;

/* Define union for FFI */
typedef union {
	long		lvalue;
	#ifdef GTK1x
	float		fvalue;
	#elif GTK2x
	double		fvalue;
	#endif
	char		*pvalue;
	GtkObject	*wvalue;
} FFITYPE;

/* Define current 'callbacked' object */
struct callback {
	GtkWidget *object;
	int state;
	int p1;
	int p2;
	int p3;
	int p4;
	int p5;
	int p6;
	int p7;
	char *text;
	int mousex;
	int mousey;
	GdkModifierType button;
};

/* Define global instance of current callback */
struct callback Current_Object;

/* Structure to define behaviour of GTK-server */
struct behaviour {
	int count_fork;			/* Keeps track of forking when in TCP mode */
	char *data;				/* Return buffer where GTK-server puts returned strings */
	int c_escaped;			/* Define if returned strings will have escaped special characters 0=off */
	char *fifo;				/* Keep name of FIFO file (Linux) */
	int log;				/* Should we create a logfile or not */
};

/* Global instance to hold the behaviour of GTK-server */
struct behaviour gtkserver;

/* Declare callback routines */
void gtk_server_callback_extra2(GtkWidget *widget, gpointer *data1);
void gtk_server_callback_extra3(GtkWidget *widget, gpointer *data1, gpointer *data2);
void gtk_server_callback_extra4(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3);
void gtk_server_callback_extra5(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4);
void gtk_server_callback_extra6(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5);
void gtk_server_callback_extra7(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5, gpointer *data6);
void gtk_server_callback_extra8(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5, gpointer *data6, gpointer *data7);

/* Collect all callback functions for gtk_server_connect */
#ifdef GTK1x
GtkCallback gtk_server_callbacks[] = {
	GTK_SIGNAL_FUNC(gtk_server_callback_extra2),
	GTK_SIGNAL_FUNC(gtk_server_callback_extra3),
	GTK_SIGNAL_FUNC(gtk_server_callback_extra4),
	GTK_SIGNAL_FUNC(gtk_server_callback_extra5),
	GTK_SIGNAL_FUNC(gtk_server_callback_extra6),
	GTK_SIGNAL_FUNC(gtk_server_callback_extra7),
	GTK_SIGNAL_FUNC(gtk_server_callback_extra8)
};
#elif GTK2x
GCallback gtk_server_callbacks[] = {
	G_CALLBACK(gtk_server_callback_extra2),
	G_CALLBACK(gtk_server_callback_extra3),
	G_CALLBACK(gtk_server_callback_extra4),
	G_CALLBACK(gtk_server_callback_extra5),
	G_CALLBACK(gtk_server_callback_extra6),
	G_CALLBACK(gtk_server_callback_extra7),
	G_CALLBACK(gtk_server_callback_extra8)
};
#endif

/* Define logfile facility */
FILE *logfile;

#ifdef LIBRARY

/* Define the returnstring, declare memory */
char *retstr;
/* Define list for CONFIGURATION settings */
CONFIG *Gtk_Api_Config;
CONFIG *Conf_Last;
CONFIG *Start_Gtk_Api_Config;

#ifdef LINUX
char *filename;
void *gtkhandle;
void *gdkhandle;
void *glibhandle;
void *extra_handle;
#endif
#ifdef WIN32
HINSTANCE gtkhandle;
HINSTANCE gdkhandle;
HINSTANCE glibhandle;
HINSTANCE extra_handle;
#endif

#endif

/*************************************************************************************************/

/* This function was rewritten by Jim Bailey */

char *Trim_String(char *data)
{
int last_idx;
/* Get rid of whitespaces at the beginning of the string */
while (*data == ' '|| *data == '\t' || *data == '\n') data++;
/* Check there is anything left to chop off at the end */
last_idx = strlen( data ) - 1;
if ( last_idx < 0 ) return data;
/* Find the last non-whitespace at the end of the string */
while ( data[last_idx] == ' ' || data[last_idx] == '\t' || data[last_idx] == '\n' ) last_idx--;
/* Actually chop off the whitespaces at the end of the string */
data[last_idx+1] = '\0';
/* Return stripped string */
return data;
}

/*************************************************************************************************/

/* Check if a charpointer really contains a number */

int is_value (char *var) 
{
int i;

if (var != NULL){
	for (i = 0; i < strlen(var); i++){
		if ((*(var + i) < 48 || *(var + i) > 57) && *(var + i) != 32 && *(var + i) != 9 && *(var + i) != 45) return 0;
	}
return 1;
}
/* If NULL, value is not a number */
return 0;
}

/*************************************************************************************************/

void Print_Error(char * fmt, int no, ...)
{
va_list args;
/* Read arguments incoming in functionheader */
va_start(args, no);
/* Linux messages go to the console */
#ifdef LINUX
vfprintf(stderr, fmt, args); 
fprintf(stderr, "\n");
#elif WIN32
char *data;
data = (char*)malloc(sizeof(char)*MAX_LEN);
vsnprintf(data, MAX_LEN, fmt, args);
/* Windows messages with messagebox */
MessageBox(NULL, data, "GTK-server error", MB_OK | MB_ICONSTOP);
free(data);
#endif
va_end(args);
/* Since this is an error, exit GTK-server */
exit(-1);
}

/*************************************************************************************************/

#ifdef LINUX
void sig_handler(int signal)
{
int status;
/* A child process was killed, decrease fork counter */
gtkserver.count_fork--;
/* Wait for child without blocking */
if (waitpid(-1, &status, WNOHANG) < 0) return;
}
#endif

/*************************************************************************************************/

/* This function is contributed by Jeremy Shute */
char* c_escape(const char* str)
{
char* c_escape_data = 0;
int c_escape_length = 0;

unsigned int i = 0, j = 0, l = 0;
char hex_buf[3];

for(i = 0; str[i]; ++i)
	switch( str[i] ) {
		case '\a': case '\t': case '\n': case '\r': case '"': l += 2;
					break;
		default:	if(str[i] < 32 || str[i] > 126) l += 4;
					else ++l;
	}

if (c_escape_length < l){
	if(c_escape_data) free(c_escape_data);
	/* Allocate 1 byte more for newline */
	c_escape_data = (char*)malloc(sizeof(char)*(l + 3 + 1));
	if(!c_escape_data) Print_Error ("%s", 1, "ERROR: Cannot allocate memory for escaped string!");
	c_escape_length = l;
}

c_escape_data[0] = '"';

for(i = 0; str[i]; ++i) {
	switch( str[i]) {
		case '\a': c_escape_data[ ++j ] = '\\'; c_escape_data[ ++j ] = 'a'; break;
		case '\t': c_escape_data[ ++j ] = '\\'; c_escape_data[ ++j ] = 't'; break;
		case '\n': c_escape_data[ ++j ] = '\\'; c_escape_data[ ++j ] = 'n'; break;
		case '\r': c_escape_data[ ++j ] = '\\'; c_escape_data[ ++j ] = 'r'; break;
		case '\"': c_escape_data[ ++j ] = '\\'; c_escape_data[ ++j ] = '"'; break;
		default: if(str[i] < 32 || str[i] > 126) {
					snprintf(hex_buf, MAX_LEN, "%02X", str[i]);
					c_escape_data[++j] = '\\';
					c_escape_data[++j] = 'x';
					c_escape_data[++j] =  hex_buf[0];
					c_escape_data[++j] =  hex_buf[1];
				}
				else c_escape_data[++j] = str[i];
	}
}

c_escape_data[++j] = '"';
c_escape_data[++j] = '\0';

return c_escape_data;
}

/*************************************************************************************************/

#ifdef LINUX
void remove_pipe(void)
{
	if (unlink(gtkserver.fifo) != 0){
		printf("Could not delete FIFO. ERROR: %s\n", strerror(errno));
	}
}
#endif

/*************************************************************************************************/

void gtk_server_callback(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5, gpointer *data6, gpointer *data7)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.p3 = (int)data3;
Current_Object.p4 = (int)data4;
Current_Object.p5 = (int)data5;
Current_Object.p6 = (int)data6;
Current_Object.p7 = (int)data7;
Current_Object.text = NULL;
}

/*************************************************************************************************/

void gtk_server_callback_extra2(GtkWidget *widget, gpointer *data1)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.text = (char*)data1;
}

void gtk_server_callback_extra3(GtkWidget *widget, gpointer *data1, gpointer *data2)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.text = (char*)data2;
}

void gtk_server_callback_extra4(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.p3 = (int)data3;
Current_Object.text = (char*)data3;
}

void gtk_server_callback_extra5(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.p3 = (int)data3;
Current_Object.p4 = (int)data4;
Current_Object.text = (char*)data4;
}

void gtk_server_callback_extra6(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.p3 = (int)data3;
Current_Object.p4 = (int)data4;
Current_Object.p5 = (int)data5;
Current_Object.text = (char*)data5;
}

void gtk_server_callback_extra7(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5, gpointer *data6)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.p3 = (int)data3;
Current_Object.p4 = (int)data4;
Current_Object.p5 = (int)data5;
Current_Object.p6 = (int)data6;
Current_Object.text = (char*)data6;
}

void gtk_server_callback_extra8(GtkWidget *widget, gpointer *data1, gpointer *data2, gpointer *data3, gpointer *data4, gpointer *data5, gpointer *data6, gpointer *data7)
{
/* Get mouse stuff */
gdk_window_get_pointer(widget->window, &Current_Object.mousex, &Current_Object.mousey, &Current_Object.button);
/* Oter data */
Current_Object.object = widget;
Current_Object.state = (int)widget;
Current_Object.p1 = (int)data1;
Current_Object.p2 = (int)data2;
Current_Object.p3 = (int)data3;
Current_Object.p4 = (int)data4;
Current_Object.p5 = (int)data5;
Current_Object.p6 = (int)data6;
Current_Object.p7 = (int)data7;
Current_Object.text = (char*)data7;
}

/*************************************************************************************************/

#ifdef LINUX
void Void_Gtk(void *gtkhandle, void *gdkhandle, void *glibhandle, void *extra_handle, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */
void (*func)();		/* In case of non-returning value */

/* Search function in GTK library */
*(void**)&func = dlsym(gtkhandle, name);
if (func == NULL) {
	*(void**)&func = dlsym(gdkhandle, name);
	if (func == NULL) {
		*(void**)&func = dlsym(glibhandle, name);
		if (func == NULL) {
			*(void**)&func = dlsym(extra_handle, name);		/* Fix by Sebastiaan van Erk */
			if (func == NULL) {
				Print_Error ("%s%s", 2, "ERROR: GTK call not found in libraries! ERROR: ", dlerror());
			}
		}
	}
}
#endif

#ifdef WIN32
void Void_Gtk(HINSTANCE hinstLib, HINSTANCE gdkLib, HINSTANCE glibLib, HINSTANCE hLib, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */
FARPROC *func;
func = (FARPROC*)malloc(sizeof(FARPROC));

/* Search function in GTK library */
*func = (FARPROC)GetProcAddress(hinstLib, name);
if (*func == NULL) {
	*func = (FARPROC)GetProcAddress(gdkLib, name);
	if (*func == NULL) {
		*func = (FARPROC)GetProcAddress(glibLib, name);
		if (*func == NULL) {
			*func = (FARPROC)GetProcAddress(hLib, name);
			if (*func == NULL){
				Print_Error ("%s", 1, "ERROR: GTK call not found in libraries!");
			}
		}
	}
}
#endif

/* Initialize the cif, realize function */
if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, atoi(amount), &ffi_type_void, argtypes) == FFI_OK)
{
	#ifdef LINUX
	ffi_call(&cif, func, NULL, argptr);
	#elif WIN32
	ffi_call(&cif, (void*)*func, NULL, argptr);
	/* Free the malloced space after the call */
	free(func);
	#endif
}
else Print_Error ("%s", 1, "ERROR: the FFI could not be initialized!");

/* Return positive response */
strcpy(retstr, "ok");
return;
}

/*************************************************************************************************/

#ifdef LINUX
void Widget_Gtk(void *gtkhandle, void *gdkhandle, void *glibhandle, void *extra_handle, char *name, char *amount, char *type, int counter, ffi_type * argtypes[], void * argptr[], char * retstr)
{
void (*func)();			/* Define function pointer */
GtkWidget *widget;		/* Temporary widget holder */
ffi_cif cif;			/* Contains pointer to FFI_CIF structure */

/* Search function in GTK library */
*(void**)&func = dlsym(gtkhandle, name);
if (func == NULL) {
	*(void**)&func = dlsym(gdkhandle, name);
	if (func == NULL) {
		*(void**)&func = dlsym(glibhandle, name);
		if (func == NULL) {
			*(void**)&func = dlsym(extra_handle, name);		/* Fix by Sebastiaan van Erk */
			if (func == NULL) {
				Print_Error ("%s%s", 2, "ERROR: GTK call not found in libraries! ERROR: ", dlerror());
			}
		}
	}
}
#endif

#ifdef WIN32
void Widget_Gtk(HINSTANCE hinstLib, HINSTANCE gdkLib, HINSTANCE glibLib, HINSTANCE hLib, char *name, char *amount, char *type, int counter, ffi_type * argtypes[], void * argptr[], char * retstr)
{
FARPROC *func;
GtkWidget *widget;		/* Temporary widget holder */
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */

func = (FARPROC*)malloc(sizeof(FARPROC));

/* Search function in GTK library */
*func = (FARPROC)GetProcAddress(hinstLib, name);
if (*func == NULL) {
	*func = (FARPROC)GetProcAddress(gdkLib, name);
	if (*func == NULL) {
		*func = (FARPROC)GetProcAddress(glibLib, name);
		if (*func == NULL) {
			*func = (FARPROC)GetProcAddress(hLib, name);
			if (*func == NULL){
				Print_Error ("%s", 1, "ERROR: GTK call not found in libraries!");
			}
		}
	}
}
#endif

/* Initialize the cif, realize function */
if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, atoi(amount), &ffi_type_pointer, argtypes) == FFI_OK)
{
	#ifdef LINUX
	ffi_call(&cif, func, &widget, argptr);
	#elif WIN32
	ffi_call(&cif, (void*)*func, &widget, argptr);
	/* Free the malloced space after the call */
	free(func);
	#endif
}
else Print_Error ("%s", 1, "ERROR: the FFI could not be initialized!");

/* Connect signals */
if (strcmp(type, "NONE")) gtk_signal_connect(GTK_OBJECT(widget), type, GTK_SIGNAL_FUNC(gtk_server_callback), (gpointer*)counter);
/* Convert to long value */
snprintf(retstr, MAX_LEN, "%d", (int)(widget));
/* Return positive response */
return;
}

/*************************************************************************************************/

#ifdef LINUX
void String_Gtk(void *gtkhandle, void *gdkhandle, void *glibhandle, void *extra_handle, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
void (*func)();			/* Define function pointer */
char *tmp;				/* temp result holder */
ffi_cif cif;			/* Contains pointer to FFI_CIF structure */

/* Search function in GTK library */
*(void**)&func = dlsym(gtkhandle, name);
if (func == NULL) {
	*(void**)&func = dlsym(gdkhandle, name);
	if (func == NULL) {
		*(void**)&func = dlsym(glibhandle, name);
		if (func == NULL) {
			*(void**)&func = dlsym(extra_handle, name);		/* Fix by Sebastiaan van Erk */
			if (func == NULL) {
				Print_Error ("%s%s", 2, "ERROR: GTK call not found in libraries! ERROR: ", dlerror());
			}
		}
	}
}
#endif

#ifdef WIN32
void String_Gtk(HINSTANCE hinstLib, HINSTANCE gdkLib, HINSTANCE glibLib, HINSTANCE hLib, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
FARPROC *func;
func = (FARPROC*)malloc(sizeof(FARPROC));
char *tmp;				/* temp result holder */
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */

/* Search function in GTK library */
*func = (FARPROC)GetProcAddress(hinstLib, name);
if (*func == NULL) {
	*func = (FARPROC)GetProcAddress(gdkLib, name);
	if (*func == NULL) {
		*func = (FARPROC)GetProcAddress(glibLib, name);
		if (*func == NULL) {
			*func = (FARPROC)GetProcAddress(hLib, name);
			if (*func == NULL){
				Print_Error ("%s", 1, "ERROR: GTK call not found in libraries!");
			}
		}
	}
}
#endif

/* Initialize the cif, realize function */
if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, atoi(amount), &ffi_type_pointer, argtypes) == FFI_OK)
{
	#ifdef LINUX
	ffi_call(&cif, func, &tmp, argptr);
	#elif WIN32
	ffi_call(&cif, (void*)*func, &tmp, argptr);
	/* Free the malloced space after the call */
	free(func);
	#endif
}
else Print_Error ("%s", 1, "ERROR: the FFI could not be initialized!");

/* Now define result */
if (tmp != NULL && strlen(tmp) > 0){
	/* Convert escaped chars if necessary - gtkserver.data gets malloced */
	if (gtkserver.c_escaped == 1) gtkserver.data = c_escape(tmp);
	/* No conversion, malloc here, return result */
	else {
		gtkserver.data = (char*)malloc(strlen(tmp) + 1);
		strcpy(gtkserver.data, tmp);
	}
}
else {
	/* Return empty string when result = NULL */
	strcpy(retstr, "");
}

/* Return */
return;
}
/*************************************************************************************************/

#ifdef LINUX
void Bool_Gtk(void *gtkhandle, void *gdkhandle, void *glibhandle, void *extra_handle, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
void (*func)();			/* In case function returns a bool */
int boolean;			/* Temporary bool holder */
ffi_cif cif;			/* Contains pointer to FFI_CIF structure */

/* Search function in GTK library */
*(void**)&func = dlsym(gtkhandle, name);
if (func == NULL) {
	*(void**)&func = dlsym(gdkhandle, name);
	if (func == NULL) {
		*(void**)&func = dlsym(glibhandle, name);
		if (func == NULL) {
			*(void**)&func = dlsym(extra_handle, name);		/* Fix by Sebastiaan van Erk */
			if (func == NULL) {
				Print_Error ("%s%s", 2, "ERROR: GTK call not found in libraries! ERROR: ", dlerror());
			}
		}
	}
}
#endif

#ifdef WIN32
void Bool_Gtk(HINSTANCE hinstLib, HINSTANCE gdkLib, HINSTANCE glibLib, HINSTANCE hLib, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
FARPROC *func;
gboolean boolean;		/* Temporary bool holder */
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */

func = (FARPROC*)malloc(sizeof(FARPROC));

/* Search function in GTK library */
*func = (FARPROC)GetProcAddress(hinstLib, name);
if (*func == NULL) {
	*func = (FARPROC)GetProcAddress(gdkLib, name);
	if (*func == NULL) {
		*func = (FARPROC)GetProcAddress(glibLib, name);
		if (*func == NULL) {
			*func = (FARPROC)GetProcAddress(hLib, name);
			if (*func == NULL){
				Print_Error ("%s", 1, "ERROR: GTK call not found in libraries!");
			}
		}
	}
}
#endif

/* Initialize the cif, realize function */
if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, atoi(amount), &ffi_type_uint, argtypes) == FFI_OK)
{
	#ifdef LINUX
	ffi_call(&cif, func, &boolean, argptr);
	#elif WIN32
	ffi_call(&cif, (void*)*func, &boolean, argptr);
	/* Free the malloced space after the call */
	free(func);
	#endif
}
else Print_Error ("%s", 1, "ERROR: the FFI could not be initialized!");

/* Convert to bool value */
if (boolean) strcpy(retstr, "1");
else strcpy(retstr, "0");
/* Return result */
return;
}

/*************************************************************************************************/

#ifdef LINUX
void Long_Gtk(void *gtkhandle, void *gdkhandle, void *glibhandle, void *extra_handle, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
void (*func)();			/* In case function returns a long */
guint result;			/* Temporary result holder */
ffi_cif cif;			/* Contains pointer to FFI_CIF structure */

/* Search function in GTK library */
*(void**)&func = dlsym(gtkhandle, name);
if (func == NULL) {
	*(void**)&func = dlsym(gdkhandle, name);
	if (func == NULL) {
		*(void**)&func = dlsym(glibhandle, name);
		if (func == NULL) {
			*(void**)&func = dlsym(extra_handle, name);		/* Fix by Sebastiaan van Erk */
			if (func == NULL) {
				Print_Error ("%s%s", 2, "ERROR: GTK call not found in libraries! ERROR: ", dlerror());
			}
		}
	}
}
#endif

#ifdef WIN32
void Long_Gtk(HINSTANCE hinstLib, HINSTANCE gdkLib, HINSTANCE glibLib, HINSTANCE hLib, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
FARPROC *func;
guint result;			/* Temporary result holder */
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */

func = (FARPROC*)malloc(sizeof(FARPROC));

/* Search function in GTK library */
*func = (FARPROC)GetProcAddress(hinstLib, name);
if (*func == NULL) {
	*func = (FARPROC)GetProcAddress(gdkLib, name);
	if (*func == NULL) {
		*func = (FARPROC)GetProcAddress(glibLib, name);
		if (*func == NULL) {
			*func = (FARPROC)GetProcAddress(hLib, name);
			if (*func == NULL){
				Print_Error ("%s", 1, "ERROR: GTK call not found in libraries!");
			}
		}
	}
}
#endif

/* Initialize the cif, realize function */
if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, atoi(amount), &ffi_type_uint, argtypes) == FFI_OK)
{
	#ifdef LINUX
	ffi_call(&cif, func, &result, argptr);
	#elif WIN32
	ffi_call(&cif, (void*)*func, &result, argptr);
	/* Free the malloced space after the call */
	free(func);
	#endif
}
else Print_Error ("%s", 1, "ERROR: the FFI could not be initialized!");

/* Convert to long value */
snprintf(retstr, MAX_LEN, "%d", result);
/*  Return positive response */
return;
}

/*************************************************************************************************/

#ifdef LINUX
void Float_Gtk(void *gtkhandle, void *gdkhandle, void *glibhandle, void *extra_handle, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
void (*func)();			/* In case function returns a float */
gfloat result;			/* Temporary result holder */
ffi_cif cif;			/* Contains pointer to FFI_CIF structure */

/* Search function in GTK library */
*(void**)&func = dlsym(gtkhandle, name);
if (func == NULL) {
	*(void**)&func = dlsym(gdkhandle, name);
	if (func == NULL) {
		*(void**)&func = dlsym(glibhandle, name);
		if (func == NULL) {
			*(void**)&func = dlsym(extra_handle, name);		/* Fix by Sebastiaan van Erk */
			if (func == NULL) {
				Print_Error ("%s%s", 2, "ERROR: GTK call not found in libraries! ERROR: ", dlerror());
			}
		}
	}
}
#endif

#ifdef WIN32
void Float_Gtk(HINSTANCE hinstLib, HINSTANCE gdkLib, HINSTANCE glibLib, HINSTANCE hLib, char *name, char *amount, ffi_type * argtypes[], void * argptr[], char * retstr)
{
FARPROC *func;
gfloat result;			/* Temporary result holder */
ffi_cif cif;		/* Contains pointer to FFI_CIF structure */

func = (FARPROC*)malloc(sizeof(FARPROC));

/* Search function in GTK library */
*func = (FARPROC)GetProcAddress(hinstLib, name);
if (*func == NULL) {
	*func = (FARPROC)GetProcAddress(gdkLib, name);
	if (*func == NULL) {
		*func = (FARPROC)GetProcAddress(glibLib, name);
		if (*func == NULL) {
			*func = (FARPROC)GetProcAddress(hLib, name);
			if (*func == NULL){
				Print_Error ("%s", 1, "ERROR: GTK call not found in libraries!");
			}
		}
	}
}
#endif

/* Initialize the cif, realize function */
if (ffi_prep_cif(&cif, FFI_DEFAULT_ABI, atoi(amount), &ffi_type_float, argtypes) == FFI_OK)
{
	#ifdef LINUX
	ffi_call(&cif, func, &result, argptr);
	#elif WIN32
	ffi_call(&cif, (void*)*func, &result, argptr);
	/* Free the malloced space after the call */
	free(func);
	#endif
}
else Print_Error ("%s", 1, "ERROR: the FFI could not be initialized!");

/* Convert to float value */
snprintf(retstr, MAX_LEN, "%f", result);
/*  Return */
return;
}

/*************************************************************************************************/

/* This is the argument parser created by Jim Bailey, adjusted slightly to fit into the GTK-server. */

GList *parse_line(char *data)
{
	GList *args = NULL;
	int start_idx = 0;
	int curr_idx = 0;
	int quote_dst_idx = 0;
	int state = 0;
	char c;

	const int in_plain     = 1 << 1;
	const int in_quotes    = 1 << 2;
	const int after_escape = 1 << 3;

	/* loop over the contents */
	for ( ; curr_idx < strlen(data) + 1; ++curr_idx )
	{
		c = data[curr_idx];

		if ( state & in_plain )
		{
			if ( c == ' ' || c == '\t' || c == '\n' || c == '\r' || curr_idx == strlen(data))
			{
				args = g_list_append(args, g_strndup(data + start_idx, curr_idx - start_idx ) );
				state ^= in_plain;
			}
		}
		else if ( state & in_quotes )
		{
			if ( state & after_escape )
			{
				if ( c == 'n' )
					c = '\n';
				else if ( c == 't' )
					c = '\t';
				else if ( c == 'r' )
					c = '\r';
				
				data[quote_dst_idx] = c;
				++quote_dst_idx;

				state ^= after_escape;
			}
			else if ( c == '"' )
			{
				args = g_list_append(args, g_strndup(data + start_idx, quote_dst_idx - start_idx ) );
				state ^= in_quotes;
			}
			else if ( c == '\\' )
			{
				state |= after_escape;
			}
			else
			{
				data[quote_dst_idx] = c;
				++quote_dst_idx;
			}
		}
		else
		{
			if ( c == '"' )
			{
				state |= in_quotes;
				start_idx = quote_dst_idx = curr_idx + 1;
			}
			else if ( c != ' ' && c != '\t' && c != '\n' && c != '\r' )
			{
				state |= in_plain;
				start_idx = curr_idx;
			}
		}
	}
	return (args);
}

/*************************************************************************************************/

#ifdef LINUX
void Call_Realize (char *inputdata, CONFIG *Find_Config, void *gtkhandle, void *gdkhandle, void *glibhandle, void* extra_handle, char * retstr)
#endif
#ifdef WIN32
void Call_Realize (char *inputdata, CONFIG *Find_Config, HINSTANCE gtkhandle, HINSTANCE gdkhandle, HINSTANCE glibhandle, HINSTANCE extra_handle, char * retstr)
#endif
{
char *gtk_api_call;
char *arg;				/* Temporary argument holders */
GList *list;			/* This will contain the list with individual arguments */
char *widget;
char *signal;
int i;

/* Stuff needed for connecting extra signals */
#ifdef GTK1x
GtkSignalQuery query;
GtkType type;
#elif GTK2x
GSignalQuery query;
GType type;
#endif
guint signal_id;

ffi_type *argtypes[MAX_ARGS];	/* Contains addresses of the types of the arguments */
void *argvalues[MAX_ARGS];		/* Contains addresses of all arguments */
FFITYPE theargs[MAX_ARGS];		/* Contains the arguemnts send by the client program */

if (strlen(inputdata) > 0) {
	/* Get the API call part */
	list = parse_line(inputdata);
	gtk_api_call = g_list_nth_data(list, 0);
	/* Have we found the GTK-signal call? */
	if (!strcmp("gtk_server_callback", gtk_api_call)) {
		/* Yes, find the first argument */
		if ((arg = g_list_nth_data(list, 1)) != NULL){
			while (1){
				/* Let GTK wait for an event */
				if (!strcmp (arg, "WAIT") || !strcmp (arg, "wait") || !strcmp(arg, "1")) {gtk_main_iteration();}
				/* Update asynchronously */
				if (!strcmp (arg, "UPDATE") || !strcmp (arg, "update") || !strcmp(arg, "2")) {while (gtk_events_pending()) gtk_main_iteration();}
				/* Find out the callback state for the given object for all arguments to gtk_server_callback */
				if ((long)Current_Object.state != GTK_SERVER_NONE) {
					/* Signal found */
					Current_Object.state = GTK_SERVER_NONE;
					/* Convert long value containing widget ref. to string */
					if (Current_Object.text == NULL) snprintf(retstr, MAX_LEN, "%d", (int)Current_Object.object);
					/* Or return self-defined string */
					else strcpy(retstr, Current_Object.text);
					break;
				}
				/* Only return with '0' to client if argument was not a WAIT argument */
				if (strcmp (arg, "WAIT") && strcmp (arg, "wait") && strcmp(arg, "1")){
					strcpy (retstr, "0");
					break;
				}
			}
		}
		/* GTK-SERVER call found, but no argument given */
		else {
			Print_Error("%s", 1, "ERROR: Missing WAIT state GTK_SERVER_CALLBACK!");
		}
	}
	/* Internal call for version */
	else if (!strcmp("gtk_server_version", gtk_api_call)){
		/* Return GTK-server version */
		strcpy(retstr, "GTK-server ");
		strcat(retstr, VERSION);
	}
	/* Call to capture incoming callback values from callback function */
	else if (!strcmp("gtk_server_callback_value", gtk_api_call)){
		/* Yes, find the first argument */
		if ((arg = g_list_nth_data(list, 1)) != NULL){
			switch (atoi(arg)){
				case 0:	snprintf(retstr, MAX_LEN, "%d", (int)Current_Object.object);
						break;
				case 1:	snprintf(retstr, MAX_LEN, "%d", Current_Object.p1);
						break;
				case 2: snprintf(retstr, MAX_LEN, "%d", Current_Object.p2);
						break;
				case 3: snprintf(retstr, MAX_LEN, "%d", Current_Object.p3);
						break;
				case 4: snprintf(retstr, MAX_LEN, "%d", Current_Object.p4);
						break;
				case 5: snprintf(retstr, MAX_LEN, "%d", Current_Object.p5);
						break;
				case 6: snprintf(retstr, MAX_LEN, "%d", Current_Object.p6);
						break;
				case 7: snprintf(retstr, MAX_LEN, "%d", Current_Object.p7);
						break;
				default:
					Print_Error("%s", 1, "ERROR: Called gtk_server_callback_value with ILLEGAL argument.");
			}
		}
		/* GTK-SERVER call found, but no argument given */
		else {
			Print_Error("%s", 1, "ERROR: Missing value identifier GTK_SERVER_CALLBACK_VALUE!");
		}
	}
	/* Internal call to connect other signals than defined in configfile */
	else if (!strcmp("gtk_server_connect", gtk_api_call)){
		if ((widget = g_list_nth_data(list, 1)) == NULL){
			Print_Error("%s", 1, "ERROR: Cannot find widget reference in GTK_SERVER_CONNECT!");
		}
		if ((signal = g_list_nth_data(list, 2)) == NULL){
			Print_Error("%s", 1, "ERROR: Cannot find signal type in GTK_SERVER_CONNECT!");
		}
		if ((arg = g_list_nth_data(list, 3)) == NULL){
			Print_Error("%s", 1, "ERROR: Cannot find response string in GTK_SERVER_CONNECT!");
		}
		/* This function was greatly improved by Wolfgang Oertl */
		#ifdef GTK1x
		type = GTK_OBJECT_TYPE((GtkObject*)(atol(widget)));
		signal_id = gtk_signal_lookup(signal, type);
		if (signal_id == 0)	Print_Error("ERROR: Cannot find signal %s!", 1, signal);
		query = *gtk_signal_query(signal_id);
		gtk_signal_connect_after(GTK_OBJECT((GtkObject*)(atol(widget))), Trim_String(signal), GTK_SIGNAL_FUNC(gtk_server_callbacks[query.nparams]), (gpointer)(strdup(arg)));
		#elif GTK2x
		type = G_OBJECT_TYPE((GtkObject*)(atol(widget)));
		signal_id = g_signal_lookup(signal, type);
		if (signal_id == 0)	Print_Error("ERROR: Cannot find signal %s!", 1, signal);
		g_signal_query(signal_id, &query);
		g_signal_connect_after(GTK_OBJECT((GtkObject*)(atol(widget))), Trim_String(signal), G_CALLBACK(gtk_server_callbacks[query.n_params]), (gpointer)(strdup(arg)));
		#endif
		/* Return OK */
		strcpy(retstr, "ok");
	}
	else if (!strcmp("GTK_SERVER_ENABLE_C_STRING_ESCAPING", gtk_api_call) || !strcmp("gtk_server_enable_c_string_escaping", gtk_api_call)){
		gtkserver.c_escaped = 1;
		/* Return OK */
		strcpy(retstr, "ok");
	}
	else if (!strcmp("GTK_SERVER_DISABLE_C_STRING_ESCAPING", gtk_api_call) || !strcmp("gtk_server_disable_c_string_escaping", gtk_api_call)){
		gtkserver.c_escaped = 0;
		/* Return OK */
		strcpy(retstr, "ok");
	}
	else if (!strcmp("gtk_server_mouse", gtk_api_call)) {
		/* Yes, find the first argument */
		if ((arg = g_list_nth_data(list, 1)) == NULL){
			Print_Error("%s", 1, "ERROR: Cannot find argument in GTK_SERVER_MOUSE!");
		}
		else {
			switch (atoi(arg)){
				case 0: snprintf(retstr, MAX_LEN, "%d", Current_Object.mousex);
						break;
				case 1: snprintf(retstr, MAX_LEN, "%d", Current_Object.mousey);
						break;
				case 2: snprintf(retstr, MAX_LEN, "%d", (int)Current_Object.button);
						break;
				default:
						Print_Error("%s", 1, "ERROR: Called gtk_server_mouse with ILLEGAL argument.");
			}
		}
	}
	/* Check if we have a GTK function redefinition */
	else if (!strcmp("gtk_server_redefine", gtk_api_call)) {
		/* Yes, find the first argument */
		if ((arg = g_list_nth_data(list, 1)) == NULL){
			Print_Error("%s", 1, "ERROR: Cannot find argument in GTK_SERVER_REDEFINE!");
		}
		/* Now find existing call in configuration */
		while ((Find_Config != NULL) && (strcmp(Find_Config->name, arg))) {
			Find_Config = Find_Config->next;
		}
		/* Have we found the GTK call? */
		if (Find_Config != NULL) {
			/* Get callbacktype */
			if (g_list_nth_data(list, 2) == NULL) {
				Print_Error("%s", 1, "ERROR: Missing callbacktype in GTK redefinition!");}
			else {
				Find_Config->callbacktype = (char*)realloc(Find_Config->callbacktype, strlen(g_list_nth_data(list, 2))*sizeof(char));
				strcpy(Find_Config->callbacktype, Trim_String(g_list_nth_data(list, 2)));}
			/* Get returnvalue */
			if (g_list_nth_data(list, 3) == NULL) {
				Print_Error("%s", 1, "ERROR: Missing returnvalue in GTK redefinition!");}
			else {
				Find_Config->returnvalue = (char*)realloc(Find_Config->returnvalue, strlen(g_list_nth_data(list, 3))*sizeof(char));
				strcpy(Find_Config->returnvalue, Trim_String(g_list_nth_data(list, 3)));}
			/* Get amount of arguments */
			if (g_list_nth_data(list, 4) == NULL) {
				Print_Error("%s", 1, "ERROR: Missing argument amount in GTK redefinition!");}
			/* Get the separate arguments */
			else {
				for (i = 0; i < atoi(g_list_nth_data(list, 4)); i++){
					if(g_list_nth_data(list, i + 5) != NULL) {
						Find_Config->args[i] = (char*)realloc(Find_Config->args[i], strlen(g_list_nth_data(list, i + 5))*sizeof(char));
						strcpy(Find_Config->args[i], Trim_String(g_list_nth_data(list, i + 5)));
					}
				}
			}
		}
		/* The redefined call was not defined before */
		else {
			Print_Error("%s", 1, "ERROR: Attempt to redefine a non-existing GTK function!");
		}

		/* Return OK */
		strcpy(retstr, "ok");
	}
	/* No GTK-SERVER call, so check for a genuine GTK call - Check GTK_CONFIG list */
	else {
		while ((Find_Config != NULL) && (strcmp(Find_Config->name, gtk_api_call))) {
			Find_Config = Find_Config->next;
		}
		/* Have we found a GTK call? */
		if (Find_Config != NULL) {
			/* Yes, now get the arguments if there are any */
			if(atoi(Find_Config->argamount) > 0){
				/* Make sure to read '.' as RADIX */
				#ifdef LINUX
				setlocale(LC_NUMERIC, "POSIX");
				#elif WIN32
				setlocale(LC_NUMERIC, "English");
				#endif
				/* Determine type of argument */
				for (i = 0; i < atoi(Find_Config->argamount); i++) {
					arg = g_list_nth_data(list, i+1);
					if (!strcmp(Find_Config->args[i], "LONG")){
						/* Check if the argument really is a number? */
						if (is_value (arg)) {
							theargs[i].lvalue = (long)atol(arg);
							argtypes[i] = &ffi_type_uint;
							argvalues[i] = &theargs[i].lvalue;
						}
						/* If not a number, then it is a string */
						else {
							theargs[i].pvalue = (char*)arg;
							argtypes[i] = &ffi_type_pointer;
							argvalues[i] = &theargs[i].pvalue;
						}
					}
					if (!strcmp(Find_Config->args[i], "WIDGET")) {
						/* Check if the value is a number > 0 */
						if (atol(arg) > 0 || !strcmp(arg, "NULL")){
							theargs[i].wvalue = (GtkObject*)(atol(arg));
							argtypes[i] = &ffi_type_pointer;
							argvalues[i] = &theargs[i].wvalue;
						}
						else Print_Error("%s%s", 2, "Cannot cast argument to widget in ", gtk_api_call);
					}
					if (!strcmp(Find_Config->args[i], "STRING")){
						theargs[i].pvalue = (char*)arg;
						argtypes[i] = &ffi_type_pointer;
						argvalues[i] = &theargs[i].pvalue;
					}
					/* The booltype in GTK is actually a value of 0 or non-0 */
					if (!strcmp(Find_Config->args[i], "BOOL")){
						theargs[i].lvalue = (long)atol(arg);
						argtypes[i] = &ffi_type_uint;
						argvalues[i] = &theargs[i].lvalue;
					}
					if (!strcmp(Find_Config->args[i], "FLOAT")){
						#ifdef GTK1x
						theargs[i].fvalue = (float)strtod(arg, NULL);
						argtypes[i] = &ffi_type_float;
						#elif GTK2x
						theargs[i].fvalue = (double)strtod(arg, NULL);
						argtypes[i] = &ffi_type_double;
						#endif
						argvalues[i] = &theargs[i].fvalue;
					}
					if (!strcmp(Find_Config->args[i], "NULL")){
						theargs[i].pvalue = NULL;
						argtypes[i] = &ffi_type_pointer;
						argvalues[i] = &theargs[i].pvalue;
					}
				}
			}
			/* The GTK CALL has no return value */
			if (!strcmp(Find_Config->returnvalue, "NONE"))
				Void_Gtk(gtkhandle, gdkhandle, glibhandle, extra_handle, Find_Config->name, Find_Config->argamount, argtypes, argvalues, retstr);
			/* The GTK CALL has a widget return value */
			else if (!strcmp(Find_Config->returnvalue, "WIDGET"))
				Widget_Gtk(gtkhandle, gdkhandle, glibhandle, extra_handle, Find_Config->name, Find_Config->argamount, Find_Config->callbacktype, Find_Config->counter, argtypes, argvalues, retstr);
			/* The GTK CALL delivers a string as a returnvalue */
			else if (!strcmp(Find_Config->returnvalue, "STRING"))
				String_Gtk(gtkhandle, gdkhandle, glibhandle, extra_handle, Find_Config->name, Find_Config->argamount, argtypes, argvalues, retstr);
			/* The GTK CALL delivers a boolean as a returnvalue */
			else if (!strcmp(Find_Config->returnvalue, "BOOL"))
				Bool_Gtk(gtkhandle, gdkhandle, glibhandle, extra_handle, Find_Config->name, Find_Config->argamount, argtypes, argvalues, retstr);
			/* The GTK CALL delivers an INTEGER as a returnvalue */
			else if (!strcmp(Find_Config->returnvalue, "LONG"))
				Long_Gtk(gtkhandle, gdkhandle, glibhandle, extra_handle, Find_Config->name, Find_Config->argamount, argtypes, argvalues, retstr);
			/* The GTK CALL delivers a FLOAT as a returnvalue */
			else if (!strcmp(Find_Config->returnvalue, "FLOAT"))
				Float_Gtk(gtkhandle, gdkhandle, glibhandle, extra_handle, Find_Config->name, Find_Config->argamount, argtypes, argvalues, retstr);
			/* Other return value (future expansion) */
			else{
				Print_Error("%s%s", 2, "ERROR: Unknown returnvalue found for GTK call: ", Find_Config->returnvalue);
			}
		}
		/* API call not found */
		else strcpy(retstr, "-1");
	}
	/* Free memory of members and list */
	g_list_foreach(list, (GFunc)g_free, NULL);
	g_list_free(list);
}
return;
}

/*************************************************************************************************
************************************************************* This is the main loop of the server
*************************************************************************************************/
#ifdef LIBRARY
void init(void)
#else
int main(int argc, char *argv[])
#endif
{
/* Define the configfile */
FILE *configfile;
/* Define the line input, declare memory */
char *line = (char*)malloc(MAX_LEN*sizeof(char));
/* Define the librarynames to open */
char *gtklibname = (char*)malloc(MAX_LEN*sizeof(char)); 
char *gdklibname = (char*)malloc(MAX_LEN*sizeof(char));
char *gliblibname = (char*)malloc(MAX_LEN*sizeof(char));
char *extra_libname = (char*)malloc(MAX_LEN*sizeof(char));
/* Define environment variable holder */ 
char *libvar;
/* Count current line number of configfile */
int count_line;
/* Define temp variable for loops */
int i;
/* Claim memory for LOGDIR definition */
char *LogDir = (char*)malloc(MAX_LEN*sizeof(char));
#ifdef WIN32
/* Needed for finding the configfile */
char filename[MAX_PATH];
int len;
#endif

#ifdef LIBRARY
/* Declare memory */
retstr = (char*)malloc(MAX_LEN*sizeof(char));
#else
/* Define the returnstring, declare memory */
char *retstr = (char*)malloc(MAX_LEN*sizeof(char));
/* Define list for CONFIGURATION settings */
CONFIG *Gtk_Api_Config;
CONFIG *Conf_Last;
CONFIG *Start_Gtk_Api_Config;
/* Define vars for TCP sockets */
char *host;
char *port;
char *maxtcp;
int sockfd;
struct hostent *he;
struct sockaddr_in my_addr;                 /* my address information */
struct sockaddr_in their_addr;				/* connector's address information (UDP) */
struct hostent *se;							/* Needed for UDP */
int new_fd;
int yes = 1;
int numbytes;
char buf[MAX_LEN];							/* Buffer containing data from socket or file */
#ifdef LINUX
char *filename;
void *gtkhandle;
void *gdkhandle;
void *glibhandle;
void *extra_handle;
socklen_t sin_size, addr_len;
/* SIGNAL struct for child processes */
struct sigaction sa;
int curpid;									/* Needed for forking */
if (!strcmp(argv[argc - 1], "log"))
	gtkserver.log = 1;						/* Check if logfile should be created */
else
	gtkserver.log = 0;
#endif
#ifdef WIN32
HINSTANCE gtkhandle;
HINSTANCE gdkhandle;
HINSTANCE glibhandle;
HINSTANCE extra_handle;
int sin_size, addr_len;
/* Needed for OS detection */
OSVERSIONINFOEX osvi;
BOOL bOsVersionInfoEx;
/* Needed for PIPES */
HANDLE hPipe1;
HANDLE hPipe2;
CHAR chRequest[MAX_LEN]; 
DWORD cbBytesRead, cbWritten; 
BOOL fSuccess;
char *dialog_msg = (char*)malloc(MAX_LEN*sizeof(char));
#endif

/* Run help if there are no arguments */
if (argc < 2) {
	#ifdef WIN32
	strcpy(dialog_msg, "*** This is the GTK-server ");
	strcat(dialog_msg, VERSION);
	strcat(dialog_msg, " *** \
		\n\r\n\rUsage:\tgtk-server = this help \
		\n\r\tgtk-server stdin [log] = start server in STDIN mode \
		\n\r\tgtk-server fifo [log] = start server in FIFO mode \
		\n\r\tgtk-server tcp <host:port> [log] = start server in TCP mode \
		\n\r\tgtk-server udp <host:port> [log] = start server in UDP mode");
	MessageBox(NULL, dialog_msg, "GTK-server usage", MB_OK | MB_ICONINFORMATION);
	exit(0);
	#endif
	#ifdef LINUX
	printf("\n*** This is the GTK-SERVER ");
	printf("%s ", VERSION);
	#ifdef GTK1x
	printf("compiled for GTK 1.x. ***\n\n");
	#elif GTK2x
	printf("compiled for GTK 2.x. ***\n\n");
	#endif
	printf("Usage:");
	printf("\tgtk-server = this help\n");
	printf("\tgtk-server stdin [log] = start server in STDIN mode\n");
	printf("\tgtk-server fifo <name> [log] = start server in FIFO mode\n");
	printf("\tgtk-server tcp <host:port[:max]> [log] = start server in TCP mode\n");
	printf("\tgtk-server udp <host:port> [log] = start server in UDP mode\n\n");
	exit (0);
	#endif
}
#endif /* ---of the LIBRARY not defined */

/* Open the config file, first in the same directory as the script */
configfile = fopen ("gtk-server.cfg", "r");
if (configfile == NULL){
	/* Try to find the environment variable GTK_SERVER_CONFIG */
	libvar = getenv("GTK_SERVER_CONFIG");
	configfile = fopen (libvar, "r");
	#ifdef WIN32
	if (configfile == NULL) {
		/* Now look for configfile in same directory as gtk-server.exe ('me') */
		GetModuleFileName(NULL, filename, MAX_PATH);
		PathRemoveExtension(filename);
		len = strlen(filename);
		filename[len] = '.';
		filename[++len] = 'c';
		filename[++len] = 'f';
		filename[++len] = 'g';
		filename[++len] = '\0';
		configfile = fopen(filename, "r");
	}
	#endif
	#ifdef LINUX
	/* Find a configfile in the default Linux directory's */
	if (configfile == NULL) {
		/* Homedir */
		libvar = getenv("HOME"); 
		if (libvar != NULL){
			filename = (char *)malloc(strlen(libvar) + 17);		/* Fix by Sebastiaan van Erk */
			strcpy(filename, libvar);
			strcat(filename, "/.gtk-server.cfg");
			configfile = fopen (filename, "r");
			free(filename);
        }
		if (configfile == NULL || libvar == NULL){
			configfile = fopen ("/etc/gtk-server.cfg", "r");
			if (configfile == NULL){
				configfile = fopen (LOCALCFG, "r");
			}
		}
	}
	#endif
}

/* No configfile found? Exit */
if (configfile == NULL) Print_Error("%s", 1, "ERROR: No 'gtk-server.cfg' file found!");

/* No escaped special chars in returnstrings */
gtkserver.c_escaped = 0;

count_line = 0;

/* Claim memory for configfile entrys */
Gtk_Api_Config = (CONFIG*)malloc(sizeof(CONFIG));
Start_Gtk_Api_Config = Gtk_Api_Config;

/* Extract the entry's of the configfile into the array */
while (fgets (line, MAX_LEN, configfile) != NULL){
	count_line++;
	/* Check if the line is a comment or the line starts with spaces */
	if (strncmp(line, "#", 1) && strlen(line) > 1) {
		/* No, check if this is the gtklibname config setting */
		if (!strncmp(line, "GTK_LIB_NAME", 12)) {
			strtok(line, "=");
			strcpy(gtklibname, Trim_String(strtok(NULL, "=")));
			if (strlen(gtklibname) <= 1) Print_Error("%s%d", 2, "ERROR: Missing GTK library name in configfile at line: ", count_line);
		}
		/* Is there a GDKlibrary? */
		else if (!strncmp(line, "GDK_LIB_NAME", 12)){
			strtok(line, "=");
			strcpy(gdklibname, Trim_String(strtok(NULL, "=")));
		}
		/* Is there a GLIBlibrary? */
		else if (!strncmp(line, "GLIB_LIB_NAME", 13)){
			strtok(line, "=");
			strcpy(gliblibname, Trim_String(strtok(NULL, "=")));
		}
		/* Is there an extra library? */
		else if (!strncmp(line, "GTK_LIB_EXTRA", 13)){
			strtok(line, "=");
			strcpy(extra_libname, Trim_String(strtok(NULL, "=")));
		}
		/* Check if we have a GTK function definition */
		else if (!strncmp(line, "GTK_LIB_FUNCTION", 16)){
			strtok(line, "=");
			Gtk_Api_Config->name = strdup(strtok(NULL, ","));
			if (Gtk_Api_Config->name != NULL) {
				/* Get rid of surrounding whitespaces */
				Gtk_Api_Config->name = Trim_String(Gtk_Api_Config->name);
				/* Get next term: callback signal type */
				if ((Gtk_Api_Config->callbacktype = strdup(Trim_String(strtok(NULL, ",")))) != NULL){
					/* Determine a unique number used for internal identification - I use the current line in the configfile */
					Gtk_Api_Config->counter = count_line;
				}
				else Print_Error("%s%d", 2, "ERROR: Missing callbacktype in GTK config file at line: ", count_line);
				/* Get next term: return value */
				if ((Gtk_Api_Config->returnvalue = strdup(Trim_String(strtok(NULL, ",")))) == NULL)
						Print_Error("%s%d", 2, "ERROR: Missing returnvalue in GTK config file at line: ", count_line);
				/* Get next term: amount of arguments */
				if ((Gtk_Api_Config->argamount = strdup(Trim_String(strtok(NULL, ",")))) == NULL)
						Print_Error("%s%d", 2, "ERROR: Missing argumentamount in GTK config file at line: ", count_line);
				/* Get the separate arguments */
				for (i = 0; i < atoi(Gtk_Api_Config->argamount); i++){
					if((Gtk_Api_Config->args[i] = strdup(Trim_String(strtok(NULL, ",")))) == NULL)
						Print_Error("%s%d", 2, "ERROR: Missing argument(s) in GTK config file at line: ", count_line);
				}
			}
			/* Declare next item */
			Conf_Last = Gtk_Api_Config;
			Gtk_Api_Config->next = (CONFIG*)malloc(sizeof(CONFIG));
			Gtk_Api_Config = Gtk_Api_Config->next;
			Gtk_Api_Config->next = NULL;
		}
		/* Check if we have a LOGDIR definition */
		else if (!strncmp(line, "GTK_SERVER_LOG", 14)){
			strtok(line, "=");
			strcpy(LogDir, Trim_String(strtok(NULL, "=")));
		}
		else Print_Error("%s%d", 2, "ERROR: Config not recognized at line: ", count_line);
		/* Claim memory for next config entry */
		/* line = (char*)malloc(MAX_LEN*sizeof(char)); */
	}
}
/* No records left, define end points */
Conf_Last->next = NULL;

/* Make sure there is a logging dir */
if (!strcmp(LogDir, "")) strcpy(LogDir, ".");

/* If last argument is 'log' then create logfile for writing */
strcat(LogDir, "/gtk-server.log");

/* For Linux, only create logfile when argument is given */
#ifdef LINUX
if (gtkserver.log == 1){
	logfile = fopen (LogDir, "w");
	if (logfile == NULL) printf("WARNING: The logfile could not be created. Please check your configfile.\n");
}
#endif

/* For Windows, always create a logfile to capture GTK warnings */
#ifdef WIN32
logfile = freopen (LogDir, "w", stderr);
if (logfile == NULL) MessageBox(NULL, "WARNING: The logfile could not be created. Please check your configfile.\n\rGTK errors will appear in a DOS box.", "GTK-server warning", MB_OK | MB_ICONEXCLAMATION);
#endif

/* Open the GTK library */
#ifdef DYNAMIC
gtkhandle = dlopen(gtklibname, RTLD_LAZY);
if (!gtkhandle){
	printf("ERROR: The GTK library could not be opened.\n");
	fputs(dlerror(), stderr);
	exit(-1);
}
if (gdklibname != NULL) gdkhandle = dlopen(gdklibname, RTLD_LAZY);
if (gliblibname != NULL) glibhandle = dlopen(gliblibname, RTLD_LAZY);
if (extra_libname != NULL) extra_handle = dlopen(extra_libname, RTLD_LAZY);
#endif

#ifdef STATIC
gtkhandle = dlopen(NULL, RTLD_LAZY);
if (!gtkhandle){
	printf("ERROR: The GTK library could not be opened.\n");
	fputs(dlerror(), stderr);
	exit(-1);
}
if (gdklibname != NULL) gdkhandle = dlopen(NULL, RTLD_LAZY);
if (gliblibname != NULL) glibhandle = dlopen(NULL, RTLD_LAZY);
if (extra_libname != NULL) extra_handle = dlopen(extra_libname, RTLD_LAZY);
#endif

#ifdef WIN32
gtkhandle = LoadLibrary(gtklibname);
if (gtkhandle == NULL) Print_Error("%s%d", 2, "ERROR: The GTK library could not be opened - ", (int)GetLastError());
if (gdklibname != NULL) gdkhandle = LoadLibrary(gdklibname);
if (gliblibname != NULL) glibhandle = LoadLibrary(gliblibname);
if (extra_libname != NULL) extra_handle = LoadLibrary(extra_libname);
#endif

/* Put string buffer of GTK-server to NULL */
gtkserver.data = NULL;

#ifndef LIBRARY
/**************************************************************************************** STDIN */
/* There is an argument, check on STDIN flag */
if (!strcmp(argv[1], "stdin")) {

	/* This is the main input loop via STDIN */
	while (1) {
		/* Perform a low-level READ and expect more than 1 byte */
		do {
			i = read(STDIN, line, MAX_LEN);
			if (i == -1){									/* Fix by Sebastiaan van Erk */
				Print_Error("%s%s", 2, "Error in reading from STDIN: ", strerror(errno));
			}
			if (i == 0) exit(0);
		} while (i < 2); 

		line[i] = '\0';

		/* If logging is enabled, write incoming text to log */
		if (argc == 3 && logfile != NULL){
			fprintf(logfile, "SCRIPT: %s\n", line);
			fflush(logfile);
		}
		Call_Realize(Trim_String(line), Start_Gtk_Api_Config, gtkhandle, gdkhandle, glibhandle, extra_handle, retstr);

		/* If logging is enabled, write returnstring to log */
		if (argc == 3 && logfile != NULL){
			if (gtkserver.data != NULL) fprintf(logfile, "SERVER: %s\n", gtkserver.data);
			else fprintf(logfile, "SERVER: %s\n", retstr);
			fflush(logfile);
		}

		/* If the string buffer is filled, print stringbuffer and free memory */
		if (gtkserver.data != NULL){
			printf("%s\n", gtkserver.data);
			free(gtkserver.data);
			gtkserver.data = NULL;
		}
		/* No string buffer, regular answer from GTK-server */
		else printf("%s\n", retstr);

		fflush(stdout);
	}
}

#ifdef LINUX
/**************************************************************************************** Linux FIFO */
/* Check on the FIFO flag */
if (!strcmp(argv[1], "fifo")) {

	gtkserver.fifo = argv[2];

	/* Make sure pipe file is removed at exit */
	if (atexit(remove_pipe) != 0) {
		if (argc == 4 && logfile != NULL){
			fprintf(logfile, "FIFO: Cannot set exit function. Please remove pipe file manually.\n");
			fflush(logfile);
		}
	}

	/* Create FIFO file */
	if (mkfifo(argv[2], S_IWUSR | S_IRUSR | S_IWGRP | S_IRGRP | S_IWOTH | S_IROTH) < 0) {
		Print_Error("%s%s", 2, "Could not create FIFO! ERROR: ", strerror(errno));
	}

	/* This is the main input loop via FIFO */
	while (1) {
		/* First open in READ mode */
		if((sockfd = open(argv[2], O_RDONLY)) < 0){
			Print_Error("%s%s", 2, "Error opening FIFO: ", strerror(errno));
		}
		/* Now wait for data */
		if((numbytes = read(sockfd, buf, MAX_LEN-1)) < 0){
			Print_Error("%s%s", 2, "Error reading FIFO: ", strerror(errno));
		}
		buf[numbytes] = '\0';
		/* Close socket again */
		if(close(sockfd) < 0){
			Print_Error("%s%s", 2, "Error closing FIFO: ", strerror(errno));
		}
		/* If logging is enabled, write incoming text to log */
		if (argc == 4 && logfile != NULL){
			fprintf(logfile, "SCRIPT: %s\n", Trim_String(buf));
			fflush(logfile);
		}
		Call_Realize(Trim_String(buf), Start_Gtk_Api_Config, gtkhandle, gdkhandle, glibhandle, extra_handle, retstr);

		/* If logging is enabled, write returnstring to log */
		if (argc == 4 && logfile != NULL){
			if (gtkserver.data != NULL) fprintf(logfile, "SERVER: %s\n", gtkserver.data);
			else fprintf(logfile, "SERVER: %s\n", retstr);
			fflush(logfile);
		}

		/* Now open in WRITE mode */
		if((sockfd = open(argv[2], O_WRONLY)) < 0){
			Print_Error("%s%s", 2, "Error opening FIFO: ", strerror(errno));
		}

		/* If the string buffer is filled, return stringbuffer and free memory */
		if (gtkserver.data != NULL){
			strcat(gtkserver.data, "\n");
			if(write (sockfd, gtkserver.data, strlen(gtkserver.data)) < 0) Print_Error("%s%s", 2, "Error writing FIFO: ", strerror(errno));
			free(gtkserver.data);
			gtkserver.data = NULL;
		}
		/* No string buffer, regular answer from GTK-server */
		else {
			/* Add newline to returned string */
			strcat(retstr, "\n");
			if(write (sockfd, retstr, strlen(retstr)) < 0) Print_Error("%s%s", 2, "Error writing FIFO: ", strerror(errno));
		}

		/* Close socket again */
		if(close(sockfd) < 0){
			Print_Error("%s%s", 2, "Error closing FIFO: ", strerror(errno));
		}
	}
}
#endif

#ifdef WIN32
/**************************************************************************************** Win32 FIFO */
/* Check for a named PIPE */
if (!strcmp(argv[1], "fifo")) {
	
	/* Checkh the Operating System version first */
	ZeroMemory(&osvi, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if( !(bOsVersionInfoEx = GetVersionEx ((OSVERSIONINFO *) &osvi))) {
		osvi.dwOSVersionInfoSize = sizeof (OSVERSIONINFO);
		if (! GetVersionEx ((OSVERSIONINFO *) &osvi)) return FALSE;
	}
	
	/* If windows9x/ME then block PIPE function */
	if (osvi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS) Print_Error("%s", 1, "ERROR: Named pipes are available on WINNT, WIN2000 and WINXP only!");
	
	/* Now create named PIPE - code ripped from msdn.microsoft.com */
	hPipe1 = CreateNamedPipe( 
		"\\\\.\\pipe\\out",         /* pipe name */
		PIPE_ACCESS_INBOUND,       /* read/write access */
		PIPE_TYPE_MESSAGE |       /* message type pipe */
		PIPE_READMODE_MESSAGE |   /* message-read mode */
		PIPE_WAIT,                /* blocking mode */
		PIPE_UNLIMITED_INSTANCES, /* max. instances */
		MAX_LEN,                  /* output buffer size */
		MAX_LEN,                  /* input buffer size */
		NMPWAIT_USE_DEFAULT_WAIT, /* client time-out */
		NULL);                    /* no security attribute */

	/* Exit if pipe cannot be created */
	if (hPipe1 == INVALID_HANDLE_VALUE) Print_Error("%s", 1, "Could not create a named pipe!"); 
	
	/* Now create named PIPE - code ripped from msdn.microsoft.com */
	hPipe2 = CreateNamedPipe( 
		"\\\\.\\pipe\\in",        /* pipe name */
		PIPE_ACCESS_OUTBOUND,     /* read/write access */
		PIPE_TYPE_MESSAGE |       /* message type pipe */
		PIPE_READMODE_MESSAGE |   /* message-read mode */
		PIPE_WAIT,                /* blocking mode */
		PIPE_UNLIMITED_INSTANCES, /* max. instances */
		MAX_LEN,                  /* output buffer size */
		MAX_LEN,                  /* input buffer size */
		NMPWAIT_USE_DEFAULT_WAIT, /* client time-out */
		NULL);                    /* no security attribute */

	/* Exit if pipe cannot be created */
	if (hPipe2 == INVALID_HANDLE_VALUE) Print_Error("%s", 1, "Could not create a named pipe!\n"); 
	
	/* Wait for connection from client script */
	if (ConnectNamedPipe(hPipe1, NULL)) {
		if (ConnectNamedPipe(hPipe2, NULL)) {

		/* This is the main input loop via FIFO */
		while(1) {

			/* Connection established, now communicate */
			fSuccess = ReadFile( 
			hPipe1,			/* handle to pipe */
			chRequest,		/* buffer to receive data */
			MAX_LEN,		/* size of buffer */
			&cbBytesRead,	/* number of bytes read */
			NULL);			/* not overlapped I/O */

			if (! fSuccess || cbBytesRead == 0) {
				Print_Error("%s%d", 2, "ERROR: GetLastError returned: ", (int)GetLastError());
				FlushFileBuffers(hPipe1);
				DisconnectNamedPipe(hPipe1);
				CloseHandle(hPipe1);
				exit(-1);
			}
			
			chRequest[cbBytesRead] = '\0';

			/* If logging is enabled, write incoming text to log */
			if (argc == 3 && logfile != NULL){
				fprintf(logfile, "SCRIPT: %s\n", chRequest);
				fflush(logfile);
			}

			Call_Realize(Trim_String(chRequest), Start_Gtk_Api_Config, gtkhandle, gdkhandle, glibhandle, extra_handle, retstr);

			/* If logging is enabled, write returnstring to log */
			if (argc == 3 && logfile != NULL){
				if (gtkserver.data != NULL) fprintf(logfile, "SERVER: %s\n", gtkserver.data);
				else fprintf(logfile, "SERVER: %s\n", retstr);
				fflush(logfile);
			}

			/* If the string buffer is filled, return stringbuffer and free memory */
			if (gtkserver.data != NULL){
				strcat(gtkserver.data, "\n");
				fSuccess = WriteFile( 
				hPipe2,			/* handle to pipe */
				gtkserver.data,	/* buffer to write from */
				strlen(gtkserver.data),	/* number of bytes to write */
				&cbWritten,		/* number of bytes written */
				NULL);			/* not overlapped I/O */
				/* Error handling */
				if (! fSuccess || strlen(gtkserver.data) != cbWritten) {
					Print_Error("%s%d", 2, "ERROR: GetLastError returned: ", (int)GetLastError());
					FlushFileBuffers(hPipe2);
					DisconnectNamedPipe(hPipe2);
					CloseHandle(hPipe2);
					exit(-1);
				}
				free(gtkserver.data);
				gtkserver.data = NULL;
			}
			else {
				/* Add newline to returned string */
				strcat(retstr, "\n");
				/* Write the reply to the pipe. */
				fSuccess = WriteFile( 
				hPipe2,			/* handle to pipe */
				retstr,			/* buffer to write from */
				strlen(retstr),	/* number of bytes to write */
				&cbWritten,		/* number of bytes written */
				NULL);			/* not overlapped I/O */
				/* Error handling */
				if (! fSuccess || strlen(retstr) != cbWritten) {
					Print_Error("%s%d", 2, "ERROR: GetLastError returned: ", (int)GetLastError());
					FlushFileBuffers(hPipe2);
					DisconnectNamedPipe(hPipe2);
					CloseHandle(hPipe2);
					exit(-1);
				}
			}
		}
		}
	
	 	else {
			/* The client could not connect, so close the pipe. */
			CloseHandle(hPipe2);
			Print_Error("%s", 1, "Connection pipe 'in' refused!");
	 	}
	}
	else {
		/* The client could not connect, so close the pipe. */
		CloseHandle(hPipe1);
		Print_Error("%s", 1, "Connection pipe 'out' refused!");
	}
}
#endif

/**************************************************************************************** TCP */
/* Else consider this to be TCP socket - host:port */
if (!strcmp(argv[1], "tcp")) {

/*Check argument format */
if (strstr(argv[2], ":") == NULL) Print_Error("%s", 1, "ERROR: Argument is in wrong format!");

host = Trim_String(strtok(argv[2], ":"));
port = Trim_String(strtok(NULL, ":"));
#ifdef LINUX
maxtcp = strtok(NULL, ":");
#endif
if (maxtcp == NULL){
	maxtcp = (char*)malloc(8*sizeof(char));
	strcpy(maxtcp, "1");
}

sockfd = 0;
#ifdef WIN32
/* Initialize Win32 environment for sockets */
WSADATA wsaData;
if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) Print_Error("%s", 1, "WSAStartup() failed!");
#endif
/* get the host info */
if ((he=gethostbyname(host)) == NULL){
	Print_Error ("%s%s", 2, "Specified host does not exist!\n\nSystem message: ", strerror(errno));
}
else if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
	Print_Error("%s%s", 2, "Cannot connect to socket!\n\nSystem message: ", strerror(errno));
}
#ifdef LINUX
else if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1)
#endif
#ifdef WIN32
else if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&yes, sizeof(int)) == -1)
#endif
{
	Print_Error("%s%s", 2, "Cannot configure socket!\n\nSystem message: ", strerror(errno));
}
/* Perform BIND to the host:port */
else {
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons((long)atol(port));             /* Fill in specified port */
	my_addr.sin_addr = *((struct in_addr *)he->h_addr);     /* Fill in specified IP address */
	memset(&(my_addr.sin_zero), '\0', 8);                   /* zero the rest of the struct */

	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) {
		Print_Error("%s%s", 2, "Unable to bind the specified socket address!\n\nSystem message: ", strerror(errno));
	}

	else if (listen(sockfd, BACKLOG) == -1) {
		Print_Error("%s%s", 2, "Unable to listen to the specified socket address!\n\nSystem message: ", strerror(errno));
	}
}
#ifdef LINUX
if (atoi(maxtcp) > 1) {
	/* Register zombie process reaper */
	sa.sa_handler = sig_handler;
	/* Do not block other signals */
	sigemptyset(&sa.sa_mask);
	sa.sa_flags = SA_RESTART;
	if (sigaction(SIGCHLD, &sa, NULL) < 0) {
		Print_Error("%s%s", 2, "Could not set signal handler! ERROR: ", strerror(errno));
	}
}
/* No forks yet */
gtkserver.count_fork = 0;
#endif
/* Now accept incoming connections */
while (1){
	sin_size = sizeof(struct sockaddr_in);
	if ((new_fd = accept(sockfd, (struct sockaddr *)&their_addr, &sin_size)) == -1){
		perror("accept");
		continue;
	}
	#ifdef WIN32
	closesocket(sockfd);
	#endif
	#ifdef LINUX
	/* Only one client may connect? No -> fork */
	if (atoi(maxtcp) > 1){
		/* Max not reached? Fork */
		if (gtkserver.count_fork < atoi(maxtcp)){
			curpid = fork();
			/* Count connect */
			gtkserver.count_fork++;
		}
	}
	else curpid = 0;
	/* We are in the non-forked process or in the child process */
	if (!curpid){
		/* Close the listener socket */
		close (sockfd);
		#endif
		/* We enter the mainloop - read incoming text */
		while(1){
			if ((numbytes = recv(new_fd, buf, MAX_LEN - 1, 0)) > 0){
				buf[numbytes] = '\0';

				/* If logging is enabled, write incoming text to log */
				if (argc == 4 && logfile != NULL){
					fprintf(logfile, "SCRIPT: %s\n", Trim_String((char*)buf));
					fflush(logfile);
				}
				Call_Realize(Trim_String((char*)buf), Start_Gtk_Api_Config, gtkhandle, gdkhandle, glibhandle, extra_handle, retstr);

				/* If logging is enabled, write returnstring to log */
				if (argc == 4 && logfile != NULL){
					if (gtkserver.data != NULL) fprintf(logfile, "SERVER: %s\n", gtkserver.data);
					else fprintf(logfile, "SERVER: %s\n", retstr);
					fflush(logfile);
				}

				/* If the string buffer is filled, return stringbuffer and free memory */
				if (gtkserver.data != NULL){
					strcat(gtkserver.data, "\n");
					send(new_fd, gtkserver.data, strlen(gtkserver.data), 0);
					free(gtkserver.data);
					gtkserver.data = NULL;
				}
				else {
					/* Add newline to returned string */
					strcat(retstr, "\n");
					/* Now send the result back to the socket */
					send(new_fd, retstr, strlen(retstr), 0);
				}
			}
			/* If disconnected, quit the gtk-server */
			else {
				exit(0);
			}
		}
	#ifdef LINUX
	}
	/* This is the parent process in case the server was forked */
	else {
		/* Close the new formed socket, the parent process does not need it */
		close (new_fd);
	}
	#endif
} /* Endless while */
} /* End TCP story */

/**************************************************************************************** UDP */
/* Else check if this to be UDP socket - host:port */
if (!strcmp(argv[1], "udp")) {

/* Check argument format */
if (strstr(argv[2], ":") == NULL) Print_Error("%s", 1, "ERROR: Argument is in wrong format!");
/* Find host IP address and port */
host = Trim_String(strtok(argv[2], ":"));
port = Trim_String(strtok(NULL, ":"));
sockfd = 0;
#ifdef WIN32
/* Initialize Win32 environment for sockets */
WSADATA wsaData;
if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) Print_Error("%s", 1, "WSAStartup() failed!");
#endif

/* Get the host info */
if ((he=gethostbyname(host)) == NULL){
	Print_Error ("%s%d", 2, "Specified host does not exist!\n\nSystem message: ", errno);
}
else if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1){
	Print_Error("%s%d", 2, "Cannot connect to socket!\n\nSystem message: ", errno);
}

/* Perform BIND to the host:port */
else {
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons((long)atol(port));             /* Fill in specified port */
	my_addr.sin_addr = *((struct in_addr *)he->h_addr);     /* Fill in specified IP address */
	memset(&(my_addr.sin_zero), '\0', 8);                   /* zero the rest of the struct */

	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1) {
		Print_Error("%s%d", 2, "Unable to bind the specified socket address!\n\nSystem message: ", errno);
	}
}

addr_len = sizeof(struct sockaddr);

/* Now accept incoming packets */
while (1){
	if ((numbytes=recvfrom(sockfd, buf, MAX_LEN - 1, 0, (struct sockaddr *)&their_addr, &addr_len)) > 0) {

		/* Terminate incoming string */
		buf[numbytes] = '\0';

		/* Only determine values when empty */
		if (se == NULL) {
			se = gethostbyname(inet_ntoa(their_addr.sin_addr));
			their_addr.sin_family = AF_INET;      /* host byte order */
			their_addr.sin_port = htons((long)atol(port));  /* short, network byte order */
			their_addr.sin_addr = *((struct in_addr *)se->h_addr);
			memset(&(their_addr.sin_zero), '\0', 8);                   /* zero the rest of the struct */
		}

		/* If logging is enabled, write incoming text to log */
		if (argc == 4 && logfile != NULL){
			fprintf(logfile, "SCRIPT: %s\n", Trim_String((char*)buf));
			fflush(logfile);
		}
		Call_Realize(Trim_String((char*)buf), Start_Gtk_Api_Config, gtkhandle, gdkhandle, glibhandle, extra_handle, retstr);

		/* If logging is enabled, write returnstring to log */
		if (argc == 4 && logfile != NULL){
			if (gtkserver.data != NULL) fprintf(logfile, "SERVER: %s\n", gtkserver.data);
			else fprintf(logfile, "SERVER: %s\n", retstr);
			fflush(logfile);
		}

		/* If the string buffer is filled, return stringbuffer and free memory */
		if (gtkserver.data != NULL){
			strcat(gtkserver.data, "\n");
			if ((numbytes=sendto(sockfd, gtkserver.data, strlen(gtkserver.data), 0, (struct sockaddr *)&their_addr, sizeof(struct sockaddr))) == -1) {
				Print_Error("%s%d", 2, "Could not send DATAGRAM packet", errno);
			}
			free(gtkserver.data);
			gtkserver.data = NULL;
		}
		else {
			/* Add newline to returned string */
			strcat(retstr, "\n");
			/* Now send the result back to the socket */
			if ((numbytes=sendto(sockfd, retstr, strlen(retstr), 0, (struct sockaddr *)&their_addr, sizeof(struct sockaddr))) == -1) {
				Print_Error("%s%d", 2, "Could not send DATAGRAM packet", errno);
			}
		}
	}
	else Print_Error("%s%d", 2, "Could not receive DATAGRAM packet", errno);

/* Endless while UDP */
}
/* End of the UDP protocol */
}

/* Arguments not recognized - return with error */
Print_Error("%s", 1, "Arguments to GTK-server not recognized!");
return -1;
#endif
}

/**************************************************************************************** LIBRARY */
#ifdef LIBRARY
void gtk_log(int i)
{
if (i != 0) gtkserver.log = 1;
else gtkserver.log = 0;
}

char *gtk (char *arg)
{
/* Check if Shared Object is initialized */
if (Start_Gtk_Api_Config == NULL) init();

/* Check if string buffer is empty */
if (gtkserver.data != NULL){
	free (gtkserver.data);
	gtkserver.data = NULL;
}

/* If logging is enabled, write incoming text to log */
if (gtkserver.log){
	fprintf(logfile, "SCRIPT: %s\n", arg);
	fflush(logfile);
}

Call_Realize(Trim_String(arg), Start_Gtk_Api_Config, gtkhandle, gdkhandle, glibhandle, extra_handle, retstr);

/* If logging is enabled, write returnstring to log */
if (gtkserver.log){
	if (gtkserver.data != NULL) fprintf(logfile, "SERVER: %s\n", gtkserver.data);
	else fprintf(logfile, "SERVER: %s\n", retstr);
	fflush(logfile);
}

/* If the string buffer is filled */
if (gtkserver.data != NULL){
	return(char*)gtkserver.data;
}
/* No string buffer, regular answer from GTK-server */
return (char*)retstr;
}

#ifdef SLANG
SLANG_MODULE(gtk);

static SLang_Intrin_Fun_Type GTK_Intrinsics [] =
{
   MAKE_INTRINSIC_1("gtk", gtk, SLANG_STRING_TYPE, SLANG_STRING_TYPE),
   MAKE_INTRINSIC_1("gtk_log", gtk_log, SLANG_VOID_TYPE, SLANG_INT_TYPE),
   SLANG_END_INTRIN_FUN_TABLE
};

int init_gtk_module_ns (char *ns_name)
{
   SLang_NameSpace_Type *ns = SLns_create_namespace (ns_name);
   if (ns == NULL)
     return -1;

  if (-1 == SLns_add_intrin_fun_table (ns, GTK_Intrinsics, "__GTK__"))
     return -1;

   return 0;
}
#endif /* End of S-Lang code */

#endif /* End of library code */

/* END */
